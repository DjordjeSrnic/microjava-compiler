// generated with ast extension for cup
// version 0.8
// 1/1/2020 23:9:41


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(PrintNumConst PrintNumConst) { }
    public void visit(ReturnType ReturnType) { }
    public void visit(OptionalUpdateStatement OptionalUpdateStatement) { }
    public void visit(Mulop Mulop) { }
    public void visit(Relop Relop) { }
    public void visit(CondTermList CondTermList) { }
    public void visit(ClassMethodDeclList ClassMethodDeclList) { }
    public void visit(StatementList StatementList) { }
    public void visit(Extends Extends) { }
    public void visit(Addop Addop) { }
    public void visit(Factor Factor) { }
    public void visit(VarList VarList) { }
    public void visit(CondFactList CondFactList) { }
    public void visit(DeclList DeclList) { }
    public void visit(Designator Designator) { }
    public void visit(Term Term) { }
    public void visit(IfCond IfCond) { }
    public void visit(ConstDeclList ConstDeclList) { }
    public void visit(VarSingle VarSingle) { }
    public void visit(MethodList MethodList) { }
    public void visit(Brackets Brackets) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(Expr Expr) { }
    public void visit(ActPars ActPars) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(Const Const) { }
    public void visit(OptionalCondition OptionalCondition) { }
    public void visit(Decl Decl) { }
    public void visit(StandardMethod StandardMethod) { }
    public void visit(OptionalDesignatorStatement OptionalDesignatorStatement) { }
    public void visit(ConstAssign ConstAssign) { }
    public void visit(Statement Statement) { }
    public void visit(VarDecl VarDecl) { }
    public void visit(Type Type) { }
    public void visit(ConstDecl ConstDecl) { }
    public void visit(CondFact CondFact) { }
    public void visit(FormPar FormPar) { }
    public void visit(MethodDeclList MethodDeclList) { }
    public void visit(AbstractClassMethodDeclList AbstractClassMethodDeclList) { }
    public void visit(FormPars FormPars) { }
    public void visit(Modulo Modulo) { visit(); }
    public void visit(Divide Divide) { visit(); }
    public void visit(Multiply Multiply) { visit(); }
    public void visit(Minus Minus) { visit(); }
    public void visit(Plus Plus) { visit(); }
    public void visit(LessOrEqual LessOrEqual) { visit(); }
    public void visit(LessThan LessThan) { visit(); }
    public void visit(GreaterOrEqual GreaterOrEqual) { visit(); }
    public void visit(GreaterThan GreaterThan) { visit(); }
    public void visit(NotEqual NotEqual) { visit(); }
    public void visit(Equal Equal) { visit(); }
    public void visit(Assignop Assignop) { visit(); }
    public void visit(DesignatorEnd DesignatorEnd) { visit(); }
    public void visit(BracketExpr BracketExpr) { visit(); }
    public void visit(DotIdent DotIdent) { visit(); }
    public void visit(SingleIdent SingleIdent) { visit(); }
    public void visit(ParenExpr ParenExpr) { visit(); }
    public void visit(ArrayInstantiation ArrayInstantiation) { visit(); }
    public void visit(ClassInstantiation ClassInstantiation) { visit(); }
    public void visit(NullFactor NullFactor) { visit(); }
    public void visit(Constant Constant) { visit(); }
    public void visit(StdMethod StdMethod) { visit(); }
    public void visit(FuncCall FuncCall) { visit(); }
    public void visit(Var Var) { visit(); }
    public void visit(SingleFactor SingleFactor) { visit(); }
    public void visit(MulOperation MulOperation) { visit(); }
    public void visit(PosTerm PosTerm) { visit(); }
    public void visit(NegTerm NegTerm) { visit(); }
    public void visit(AddOperation AddOperation) { visit(); }
    public void visit(CompareExpr CompareExpr) { visit(); }
    public void visit(SingleExpr SingleExpr) { visit(); }
    public void visit(NoCondFacts NoCondFacts) { visit(); }
    public void visit(MultipleCondFacts MultipleCondFacts) { visit(); }
    public void visit(CondTerm CondTerm) { visit(); }
    public void visit(OrBegin OrBegin) { visit(); }
    public void visit(NoCondTerms NoCondTerms) { visit(); }
    public void visit(MultipleCondTerms MultipleCondTerms) { visit(); }
    public void visit(Condition Condition) { visit(); }
    public void visit(NoActualParams NoActualParams) { visit(); }
    public void visit(ActualParam ActualParam) { visit(); }
    public void visit(ActualParams ActualParams) { visit(); }
    public void visit(CallBegin CallBegin) { visit(); }
    public void visit(Decrement Decrement) { visit(); }
    public void visit(Increment Increment) { visit(); }
    public void visit(FunctionCall FunctionCall) { visit(); }
    public void visit(DesignatorStandardMethod DesignatorStandardMethod) { visit(); }
    public void visit(ErrorAssignOper ErrorAssignOper) { visit(); }
    public void visit(AssignOper AssignOper) { visit(); }
    public void visit(NoOptCondition NoOptCondition) { visit(); }
    public void visit(ErrorOptCondition ErrorOptCondition) { visit(); }
    public void visit(OptCondition OptCondition) { visit(); }
    public void visit(NoOptUpdateStatement NoOptUpdateStatement) { visit(); }
    public void visit(OptUpdateStatement OptUpdateStatement) { visit(); }
    public void visit(NoOptDesignatorStatement NoOptDesignatorStatement) { visit(); }
    public void visit(OptDesignatorStatement OptDesignatorStatement) { visit(); }
    public void visit(NoStatements NoStatements) { visit(); }
    public void visit(Statements Statements) { visit(); }
    public void visit(PrintNoNumConst PrintNoNumConst) { visit(); }
    public void visit(PrintWithNumConst PrintWithNumConst) { visit(); }
    public void visit(ForBody ForBody) { visit(); }
    public void visit(ForBegin ForBegin) { visit(); }
    public void visit(ForStatement ForStatement) { visit(); }
    public void visit(ElseBegin ElseBegin) { visit(); }
    public void visit(IfCondition IfCondition) { visit(); }
    public void visit(IfBegin IfBegin) { visit(); }
    public void visit(ListStatement ListStatement) { visit(); }
    public void visit(PrintStatement PrintStatement) { visit(); }
    public void visit(ReadStatement ReadStatement) { visit(); }
    public void visit(ReturnStatementWithExpr ReturnStatementWithExpr) { visit(); }
    public void visit(ReturnStatementNoExpr ReturnStatementNoExpr) { visit(); }
    public void visit(ContinueStatement ContinueStatement) { visit(); }
    public void visit(BreakStatement BreakStatement) { visit(); }
    public void visit(StatementFor StatementFor) { visit(); }
    public void visit(StatementIfElse StatementIfElse) { visit(); }
    public void visit(StatementIf StatementIf) { visit(); }
    public void visit(DesignatorStmt DesignatorStmt) { visit(); }
    public void visit(StandardMethodLen StandardMethodLen) { visit(); }
    public void visit(StandardMethodOrd StandardMethodOrd) { visit(); }
    public void visit(StandardMethodChr StandardMethodChr) { visit(); }
    public void visit(TypeCustom TypeCustom) { visit(); }
    public void visit(TypeChar TypeChar) { visit(); }
    public void visit(TypeBool TypeBool) { visit(); }
    public void visit(TypeInt TypeInt) { visit(); }
    public void visit(ErrorFormParType ErrorFormParType) { visit(); }
    public void visit(FormParameter FormParameter) { visit(); }
    public void visit(NoFormPars NoFormPars) { visit(); }
    public void visit(SingleFormExpr SingleFormExpr) { visit(); }
    public void visit(MultipleFormExprs MultipleFormExprs) { visit(); }
    public void visit(AbstractMethodBegin AbstractMethodBegin) { visit(); }
    public void visit(AbstractMethodDecl AbstractMethodDecl) { visit(); }
    public void visit(ReturnVoid ReturnVoid) { visit(); }
    public void visit(ReturnT ReturnT) { visit(); }
    public void visit(MethodVarsEnd MethodVarsEnd) { visit(); }
    public void visit(MethodFormParsEnd MethodFormParsEnd) { visit(); }
    public void visit(MethodBegin MethodBegin) { visit(); }
    public void visit(NoMethodDecl NoMethodDecl) { visit(); }
    public void visit(MethodDeclarations MethodDeclarations) { visit(); }
    public void visit(MethodDecl MethodDecl) { visit(); }
    public void visit(OneOrMoreAbstractMethods OneOrMoreAbstractMethods) { visit(); }
    public void visit(OneOrMoreDefinedMethods OneOrMoreDefinedMethods) { visit(); }
    public void visit(SingleAbstractMethod SingleAbstractMethod) { visit(); }
    public void visit(SingleDefinedMethod SingleDefinedMethod) { visit(); }
    public void visit(AbstractMethodDeclarationListNO AbstractMethodDeclarationListNO) { visit(); }
    public void visit(AbstractMethodDeclarationList AbstractMethodDeclarationList) { visit(); }
    public void visit(AbstractClassDecl AbstractClassDecl) { visit(); }
    public void visit(AbstractClassBegin AbstractClassBegin) { visit(); }
    public void visit(NoExtend NoExtend) { visit(); }
    public void visit(ErrorExtends ErrorExtends) { visit(); }
    public void visit(Extend Extend) { visit(); }
    public void visit(MethodDeclarationListNO MethodDeclarationListNO) { visit(); }
    public void visit(MethodDeclarationList MethodDeclarationList) { visit(); }
    public void visit(ClassVarDeclList ClassVarDeclList) { visit(); }
    public void visit(ClassDecl ClassDecl) { visit(); }
    public void visit(ClassBegin ClassBegin) { visit(); }
    public void visit(NoBrackets NoBrackets) { visit(); }
    public void visit(Bracket Bracket) { visit(); }
    public void visit(NoVarDecl NoVarDecl) { visit(); }
    public void visit(VarDecls VarDecls) { visit(); }
    public void visit(ErrorVarSingle ErrorVarSingle) { visit(); }
    public void visit(VariableSingle VariableSingle) { visit(); }
    public void visit(SingleVar SingleVar) { visit(); }
    public void visit(MultipleVar MultipleVar) { visit(); }
    public void visit(ErroreVarDecl ErroreVarDecl) { visit(); }
    public void visit(VarDeclaration VarDeclaration) { visit(); }
    public void visit(BoolConst BoolConst) { visit(); }
    public void visit(CharConst CharConst) { visit(); }
    public void visit(NumConst NumConst) { visit(); }
    public void visit(ConstantAssign ConstantAssign) { visit(); }
    public void visit(MultipleConstDecls MultipleConstDecls) { visit(); }
    public void visit(SingleConstDecl SingleConstDecl) { visit(); }
    public void visit(ConstantDecl ConstantDecl) { visit(); }
    public void visit(ClassDeclarations ClassDeclarations) { visit(); }
    public void visit(AbstractDeclarations AbstractDeclarations) { visit(); }
    public void visit(VarDeclarations VarDeclarations) { visit(); }
    public void visit(ConstDeclarations ConstDeclarations) { visit(); }
    public void visit(NoDecl NoDecl) { visit(); }
    public void visit(Declarations Declarations) { visit(); }
    public void visit(ProgName ProgName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
