package rs.ac.bg.etf.pp1;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import java_cup.runtime.Symbol;
import rs.ac.bg.etf.pp1.ast.Program;
import rs.ac.bg.etf.pp1.help.MyTab;
import rs.ac.bg.etf.pp1.help.TableDumpVisitor;
import rs.ac.bg.etf.pp1.util.Log4JUtils;
import rs.etf.pp1.mj.runtime.Code;

public class Compiler {

	static {
        DOMConfigurator.configure(Log4JUtils.instance().findLoggerConfigFile());
        Log4JUtils.instance().prepareLogFile(Logger.getRootLogger());
    }

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        Logger log = Logger.getLogger(Compiler.class);


        if (args.length < 2) {
			log.error("Nema dovoljno argumenata! ");
			System.err.println("Nema dovoljno argumenata! ");
			return;
		}		
        
        File sourceCode = new File(args[0]);
        
        if (!sourceCode.exists()) {
            log.error("Source fajl [" + sourceCode.getAbsolutePath() + "] nije pronadjen!");
            System.err.println("Source fajl [" + sourceCode.getAbsolutePath() + "] nije pronadjen!");
            return;
        }

        log.info("Prevodjenje source fajla: " + sourceCode.getAbsolutePath());
        String path = sourceCode.getAbsolutePath();
        System.setOut(new PrintStream(new FileOutputStream(path.substring(0, path.length()-3)+".out")));
		System.setErr(new PrintStream(new FileOutputStream(path.substring(0, path.length()-3)+".err")));

        try (BufferedReader br = new BufferedReader(new FileReader(sourceCode))) {
            Yylex lexer = new Yylex(br);
            MJParser parser = new MJParser(lexer);
            Symbol s = parser.parse();
            Program program = (Program) (s.value);
            System.out.println(program.toString(""));
            
            if(parser.errorDetected) {
				System.err.println("=====================Sintaksna analiza nije uspesno zavrsena======================");
				log.error("=====================Sintaksna analiza nije uspesno zavrsena======================");
			}else {
				System.out.println("========================Sintaksna analiza uspesno zavrsena========================");
				log.info("========================Sintaksna analiza uspesno zavrsena========================");
			}

            MyTab.init();
            SemanticAnalyzer semanticAnalyzer = new SemanticAnalyzer();
            program.traverseBottomUp(semanticAnalyzer);
            tsdump();
            
            if(semanticAnalyzer.passed()) {
				System.out.println("=======================Semanticka analiza uspesno zavrsena========================");
				log.info("=======================Semanticka analiza uspesno zavrsena========================");
			}
			else {
				System.err.println("=====================Semanticka analiza nije uspesno zavrsena=====================");
				log.error("=====================Semanticka analiza nije uspesno zavrsena=====================");
			}

            if (!parser.errorDetected && semanticAnalyzer.passed()) {

                File objFile = new File(args[1]);
                log.info("Generisanje bytecode fajla: " + objFile.getAbsolutePath());
                if (objFile.exists())
                    objFile.delete();

                CodeGenerator codeGenerator = new CodeGenerator();
                Code.dataSize = semanticAnalyzer.nVars;

                program.traverseBottomUp(codeGenerator);

                Code.write(new FileOutputStream(objFile));
                System.out.println("=============================Zavrseno generisanje koda============================");
				log.info("=============================Zavrseno generisanje koda============================");

            } else {
            	System.err.println("=====Kod nije izgenerisan zbog gresaka u semantickoj i/ili sintaksnoj analizi=====");
				log.error("=====Kod nije izgenerisan zbog gresaka u semantickoj i/ili sintaksnoj analizi=====");
            }
            
            br.close();
        }
    }
    
    private static void  tsdump() {
		MyTab.dump(new TableDumpVisitor());
	}
}
