package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.ast.*;

import rs.ac.bg.etf.pp1.help.Konstanta;
import rs.ac.bg.etf.pp1.help.MyTab;
import rs.ac.bg.etf.pp1.help.Variable;
import rs.etf.pp1.symboltable.*;
import rs.etf.pp1.symboltable.concepts.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

import org.apache.log4j.Logger;

public class SemanticAnalyzer extends VisitorAdaptor {

	int nVars = 0;
	
	private int numberOfParameters = 0;
	private Obj currentMethod = null;
	private Struct currentClass = null;
	private boolean errorDetected = false;
	private boolean isReturned = false;
	private Stack<ArrayList<Struct>> functionCallArguments = new Stack<>();
	private HashMap<Struct, Struct> arrayTypes = new HashMap<>();
	private HashMap<String, Boolean> baseMethods = new HashMap<>();
    private HashMap<String, Boolean> redefinedMethods = new HashMap<>();
    private String superclassName = "";
    private HashMap<String, Boolean> abstractClasses = new HashMap<>();
    private HashMap<String, String> abstractClassMethods = new HashMap<>();
    private boolean inAbstractClass = false;
    private String abstractClassName = "";
    private boolean foundMain = false;
    private int baseNumberOfParameters = 0;
    private ArrayList<Obj> baseMethodVars;
    private int loop = 0;
	
	Logger log = Logger.getLogger(getClass());
	
	
	public void report_error(String message, SyntaxNode info) {
		errorDetected = true;
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0 : info.getLine();
		if (line != 0)
			msg.append(" na liniji ").append(line);
		log.error(msg.toString());
		System.err.println(msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0 : info.getLine();
		if (line != 0)
			msg.append(" na liniji ").append(line);
		log.info(msg.toString());
		System.out.println(msg.toString());
	}
	
// PROGRAM START
	
	public void visit(ProgName progName) {
		progName.obj = MyTab.insert(Obj.Prog, progName.getProgName(), MyTab.noType);
		MyTab.openScope();
	}
	
	
// PROGRAM END
	
	public void visit(Program program) {
		nVars = MyTab.currentScope.getLocals().symbols().size();
		MyTab.chainLocalSymbols(program.getProgName().obj);
		MyTab.closeScope();
	}
	
	
// ACT PARS
	
    public void visit(ActualParam actParam) {
        if (!functionCallArguments.empty()) {
            functionCallArguments.peek().add(actParam.getExpr().struct);
        }
    }

    public void visit(ActualParams actParams) {
        if (!functionCallArguments.empty()) {
            functionCallArguments.peek().add(actParams.getExpr().struct);
        }
    }
    
// CONDITION
    
    public void visit(Condition condition) {
        if (condition.getCondTerm().struct != MyTab.boolType
                || condition.getCondTermList().struct != MyTab.boolType) {
            report_error("Uslov mora biti bool tipa", condition);
            condition.struct = MyTab.noType;
        } else {
            condition.struct = MyTab.boolType;
        }
    }
    
// COND TERM
    
    public void visit(MultipleCondTerms condTermList) {
        if (condTermList.getCondTermList().struct != MyTab.boolType) {
        	condTermList.struct = MyTab.noType;
        } else if (condTermList.getCondTerm().struct != MyTab.boolType) {
        	condTermList.struct = MyTab.noType;
        } else {
        	condTermList.struct = MyTab.boolType;
        }
    }

    public void visit(NoCondTerms noCondTerms) {
    	noCondTerms.struct = MyTab.boolType;
    }

    public void visit(CondTerm condTerm) {
        if (condTerm.getCondFact().struct != MyTab.boolType) {
            condTerm.struct = MyTab.noType;
        } else if (condTerm.getCondFactList().struct != MyTab.boolType) {
            condTerm.struct = MyTab.noType;
        } else {
            condTerm.struct = MyTab.boolType;
        }
    }

// COND FACT
    
    public void visit(MultipleCondFacts condFactList) {
        if (condFactList.getCondFactList().struct != MyTab.boolType) {
        	condFactList.struct = MyTab.noType;
        } else if (condFactList.getCondFact().struct != MyTab.boolType) {
        	condFactList.struct = MyTab.noType;
        } else {
        	condFactList.struct = MyTab.boolType;
        }
    }

    public void visit(NoCondFacts noCondFacts) {
        noCondFacts.struct = MyTab.boolType;
    }

    public void visit(SingleExpr condFactExpr) {
        condFactExpr.struct = condFactExpr.getExpr().struct;
    }

    public void visit(CompareExpr condFactCompare) {
        Struct struct1 = condFactCompare.getExpr().struct;
        Struct struct2 = condFactCompare.getExpr1().struct;
        
        if (!MyTab.CompatibleWith(struct1, struct2)) {
            report_error("Operandi nisu kompatibilni", condFactCompare);
        } else if ((struct1.isRefType() || struct2.isRefType()) && !(condFactCompare.getRelop() instanceof Equal)
                && !(condFactCompare.getRelop() instanceof NotEqual)) {
            report_error("Nizovi i objekti se mogu porediti samo sa != i ==", condFactCompare);
        }
        condFactCompare.struct = MyTab.boolType;
    }
    
// EXPR
    
    public void visit(PosTerm posTerm) {
    	posTerm.struct = posTerm.getTerm().struct;
    }

    public void visit(NegTerm negTerm) {
        if (negTerm.getTerm().struct != MyTab.intType) {
            report_error("Negacija moze da se primeni samo na cele brojeve", negTerm);
            negTerm.struct = MyTab.noType;
        } else {
        	negTerm.struct = negTerm.getTerm().struct;
        }
    }

    public void visit(AddOperation addOper) {
        Struct left = addOper.getExpr().struct;
        Struct right = addOper.getTerm().struct;
        
        if (left.getKind() == Struct.Int && right.getKind() == Struct.Int) {
        	addOper.struct = MyTab.intType;
        } else {
            report_error("Operacija radi samo nad celim brojevima", addOper);
            addOper.struct = MyTab.noType;
        }
    }
    
// TERM
    
    public void visit(SingleFactor singleFactor) {
    	singleFactor.struct = singleFactor.getFactor().struct;
    }

    public void visit(MulOperation mulOper) {
        Struct left = mulOper.getFactor().struct;
        Struct right = mulOper.getTerm().struct;

        if (left.getKind() == Struct.Int && right.getKind() == Struct.Int) {
        	mulOper.struct = MyTab.intType;
        } else {
            report_error("Operacija radi samo nad celim brojevima", mulOper);
            mulOper.struct = MyTab.noType;
        }
    }
    
// FACTOR
    
    public void visit(Var var) {
        var.struct = var.getDesignator().obj.getType();
    }
    
    public void visit(StdMethod factorStandardFunction) {
        factorStandardFunction.struct = factorStandardFunction.getStandardMethod().struct;
    }
    
    public void visit(FuncCall factorFunctionCall) {
        Obj method = factorFunctionCall.getDesignator().obj;
      
        ArrayList<Struct> arguments = functionCallArguments.pop();
        
        if (method.getKind() != Obj.Meth) {
            if (method != MyTab.noObj)
                report_error(method.getName() + " nije ime metode ni funkcije", factorFunctionCall);
            factorFunctionCall.struct = MyTab.noType;
            return;
        } else {
            factorFunctionCall.struct = method.getType();
            
            ArrayList<Obj> parameters = new ArrayList<>(method.getLocalSymbols());
            int numberOfParameters = method.getLevel();
            
            if (parameters.size() != 0 && parameters.get(0) != null && parameters.get(0).getName().equals("this")) {
                parameters.remove(0);
                numberOfParameters--;
            }
            
            if (arguments.size() != numberOfParameters) {
                report_error("Netacan broj argumenata za poziv " + method.getName(), factorFunctionCall);
            } else {
                for (int i = 0; i < numberOfParameters; i++) {
                    Struct argument = arguments.remove(0);
                    Struct parameter = parameters.remove(0).getType();
                    if (!MyTab.AssignableTo(parameter, argument)) {
                        report_error((i + 1) + ". argument ne moze da se dodeli odgovarajucem parametru",
                                factorFunctionCall);
                    }
                }
            }
        }
    }
    
    public void visit(Constant constant) {
    	constant.struct = constant.getConst().konstanta.getObj().getType();
    }
    
    public void visit(ClassInstantiation newObj) {
        if (newObj.getType().struct.getKind() != Struct.Class) {
            report_error("Sa new moze da se napravi samo objekat klasnog tipa", newObj);
            newObj.struct = MyTab.noType;
        } else {
        	String className = ((TypeCustom) newObj.getType()).getTypeName();
        	if (abstractClasses.get(className) != null) {
        		if (abstractClasses.get(className) == false) {
        			 report_error("Sa new NE MOZE da se napravi objekat apstraktne klase", newObj);
        	         newObj.struct = MyTab.noType;
        	         return;
        		}
        	}
        	
        	newObj.struct = newObj.getType().struct;
        }
    }

    public void visit(ArrayInstantiation newArray) {
        if (newArray.getExpr().struct != MyTab.intType) {
            report_error("Velicina niza mora biti int", newArray);
            newArray.struct = MyTab.noType;
        } else {
            if (arrayTypes.get(newArray.getType().struct) == null) {
                arrayTypes.put(newArray.getType().struct,
                        new Struct(Struct.Array, newArray.getType().struct));
            }

            newArray.struct = arrayTypes.get(newArray.getType().struct);
        }
    }
    
    public void visit(NullFactor nullFactor) {
        nullFactor.struct = MyTab.nullType;
    }
    
    public void visit(ParenExpr pExpr) {
    	pExpr.struct = pExpr.getExpr().struct;
    }
    
// DESIGNATOR
    
    public void visit(SingleIdent singleIdent) {
        if (singleIdent.getParent() instanceof FuncCall
                || singleIdent.getParent() instanceof FunctionCall) {
            functionCallArguments.push(new ArrayList<>());
        }
       
        Obj obj = MyTab.find(singleIdent.getName());
        if (obj == MyTab.noObj) {
            report_error("Ime " + singleIdent.getName() + " nije deklarisano", singleIdent);
            singleIdent.obj = MyTab.noObj;
        } else {
            singleIdent.obj = obj;
        
	        switch(singleIdent.obj.getKind()) {
	        case Obj.Con:
	        	report_info("Detektovana upotreba simbolicke konstante " + singleIdent.getName() + " na liniji " + singleIdent.getLine()  + ": "
						+ printNode(singleIdent.obj, -1), null);
				break;
				
	        case Obj.Meth:
				if (currentClass != null && currentClass.getMembersTable().searchKey(singleIdent.getName()) != null)
					report_info("Detektovan poziv metode " + singleIdent.getName() + " unutrasnje klase " + " na liniji "
							+ singleIdent.getLine() + ": " + printNode(singleIdent.obj, -1), null);
				else
					report_info("Detektovan poziv globalne funkcije " + singleIdent.getName() + " na liniji " + singleIdent.getLine()
					+ ": " + printNode(singleIdent.obj, -1), null);
				break;
				
	        case Obj.Var:
				if (singleIdent.obj.getFpPos() > 0)
					report_info("Detektovana upotreba formalnog parametra " + singleIdent.getName() + " metode "
									+ currentMethod.getName() + " na liniji " + singleIdent.getLine() + ": "
											+ printNode(singleIdent.obj, -1), null);
				else if (currentMethod == null)
					report_info("Detektovana upotreba globalne promenljive " + singleIdent.getName() + " na liniji " + singleIdent.getLine()
					+ ": " + printNode(singleIdent.obj, -1), null);
				break;
	        }
        }
    }

    public void visit(DotIdent dotIdent) {
        if (dotIdent.getParent() instanceof FuncCall
                || dotIdent.getParent() instanceof FunctionCall) {
        	
            functionCallArguments.push(new ArrayList<>());
        }

        if (dotIdent.getDesignator().obj != MyTab.noObj) {
            Struct struct = dotIdent.getDesignator().obj.getType();
            
            if (struct.getKind() != Struct.Class) {
                report_error("Moze se pristupati samo poljima klasnih tipova ", dotIdent);
                dotIdent.obj = MyTab.noObj;
            } else {
                Obj elem = struct.getMembers().stream().filter(e -> e.getName().equals(dotIdent.getName()))
                        .findFirst().orElse(null);
                
                if (elem == null) {
                    report_error("Ne postoji ime " + dotIdent.getName(), dotIdent);
                    dotIdent.obj = MyTab.noObj;
                } else {
                    dotIdent.obj = elem;
                    
                    if (struct.getKind() == Struct.Class) {
                        if (elem.getKind() == Obj.Meth) {
                            report_info("Detektovan poziv metode " + elem.getName() + " unutrasnje klase " + " na liniji " +
                            		dotIdent.getLine() + ": " + printNode(dotIdent.obj, -1),
                                    dotIdent);
                        } else {
                            report_info("Detektovan pristup polju " + elem.getName() + " unutrasnje klase " + " na liniji " +
                            		dotIdent.getLine() + ": " + printNode(dotIdent.obj, -1),
                                    dotIdent);
                        }
                    }
                }
            }
        } else {
            dotIdent.obj = MyTab.noObj;
        }
    }

    public void visit(BracketExpr bracketExpr) {
        Obj obj = bracketExpr.getDesignator().obj;
        if (obj != MyTab.noObj) {
            String arrayName = obj.getName();
            if (obj.getType().getKind() != Struct.Array) {
                report_error("Promenljiva " + arrayName + " nije niz", bracketExpr);
                bracketExpr.obj = MyTab.noObj;
            } else if (bracketExpr.getExpr().struct.getKind() != Struct.Int) {
                report_error("Za indeksiranje niza mora da se koristi int", bracketExpr);
                bracketExpr.obj = MyTab.noObj;
            } else {
                bracketExpr.obj = new Obj(Obj.Elem, "elem" + arrayName, obj.getType().getElemType());
                report_info("Detektovan pristup elementu niza " + obj.getName() + " na liniji " + bracketExpr.getLine() + ": "
						+ printNode(bracketExpr.obj, -1), bracketExpr);
            }
        } else {
            bracketExpr.obj = MyTab.noObj;
        }
    }
	
// DESIGNATOR STATEMENT

	public void visit(AssignOper designatorAssign) {
        if (isLValue(designatorAssign.getDesignator())) {
            Struct left = designatorAssign.getDesignator().obj.getType();
            Struct right = designatorAssign.getExpr().struct;
            
            if (MyTab.AssignableTo(left, right)) {
                return;
            }
            
            report_error("Tipovi u dodeli nisu kompatiblini", designatorAssign);
        } else {
            report_error("Kod dodele vrednosti leva strana mora biti promenljiva, polje klase ili element niza",
                    designatorAssign);
        }
    }
	
    public void visit(FunctionCall designatorFunctionCall) {
        Obj method = designatorFunctionCall.getDesignator().obj;
        
        ArrayList<Struct> arguments = functionCallArguments.pop();
        
        if (method.getKind() != Obj.Meth) {
            if (method != MyTab.noObj)
                report_error(method.getName() + " nije ime metode ni funkcije", designatorFunctionCall);
            return;
        } else {
   
            ArrayList<Obj> parameters = new ArrayList<>(method.getLocalSymbols());
            int numberOfParameters = method.getLevel();
            
            if (parameters.size() != 0 && parameters.get(0) != null && parameters.get(0).getName().equals("this")) {
                parameters.remove(0);
                numberOfParameters--;
            }
        
            if (arguments.size() != numberOfParameters) {
                report_error("Netacan broj argumenata za poziv " + method.getName(), designatorFunctionCall);
            } else {
                for (int i = 0; i < numberOfParameters; i++) {
                    Struct argument = arguments.remove(0);
                    Struct parameter = parameters.remove(0).getType();
                    if (!MyTab.AssignableTo(parameter, argument)) {
                        report_error((i + 1) + ". argument ne moze da se dodeli odgovarajucem parametru",
                                designatorFunctionCall);
                    }
                }
            }
        }
    }
 
    public void visit(Increment increment) {
        if (isLValue(increment.getDesignator())) {
            Struct struct = increment.getDesignator().obj.getType();

            if (struct.getKind() != Struct.Int) {
                report_error("Samo se ceo broj moze inkrementirati", increment);
            }
        } else {
            report_error("Kod inkrementiranja leva strana mora biti promenljiva, polje klase ili element niza",
                    increment);
        }
    }

    public void visit(Decrement decrement) {
        if (isLValue(decrement.getDesignator())) {
            Struct struct = decrement.getDesignator().obj.getType();
            
            if (struct.getKind() != Struct.Int) {
                report_error("Samo se ceo broj moze dekrementirati", decrement);
            }
        } else {
            report_error("Kod dekrementiranja leva strana mora biti promenljiva, polje klase ili element niza",
                    decrement);
        }
    }

	
// CLASS
    
    public void visit(ClassBegin classBegin) {
        if (MyTab.currentScope.findSymbol(classBegin.getClassName())!=null) {
            report_error("Ime klase " + classBegin.getClassName() + " vec postoji u trenutnom opsegu", classBegin);
            currentClass = new Struct(Struct.None);
        } else {
            currentClass = new Struct(Struct.Class);
            MyTab.insert(Obj.Type, classBegin.getClassName(), currentClass);
            classBegin.struct = currentClass;
        }
        MyTab.openScope();
        MyTab.insert(Obj.Fld, "vtp", MyTab.intType);
    }
    
    
    public void visit(ClassVarDeclList classVarDeclList) {
        if (currentClass == null) {
            return;
        }
       
        MyTab.chainLocalSymbols(currentClass);
             
        if (currentClass.getElemType() != null) {
            for (Obj field : currentClass.getElemType().getMembers()) {
                if (field.getKind() == Obj.Meth) {
                	if (abstractClassMethods.get(field.getName()) != null && superclassName.equals(abstractClassMethods.get(field.getName())))
                		baseMethods.put(field.getName(), false);
                	else
                		baseMethods.put(field.getName(), true);
                	
                	redefinedMethods.put(field.getName(), false);
                	
                    Obj newMethod = new Obj(field.getKind(), field.getName(), field.getType(), field.getAdr(),
                            field.getLevel());
                    newMethod.setFpPos(field.getFpPos());
                
                    if (!field.getLocalSymbols().isEmpty()) {
                        Scope tempScope = new Scope(null);
                        for (Obj localVar : field.getLocalSymbols()) {
                            Obj newLocalVar;
                            
                            if (localVar.getName() != "this") {
                                newLocalVar = new Obj(localVar.getKind(), localVar.getName(), localVar.getType(),
                                        localVar.getAdr(), localVar.getLevel());
                            } else {
                                newLocalVar = new Obj(localVar.getKind(), localVar.getName(), currentClass,
                                        localVar.getAdr(), localVar.getLevel());
                            }
                            tempScope.addToLocals(newLocalVar);
                        }
                        
                        newMethod.setLocals(tempScope.getLocals());
                    }
                    
                    MyTab.currentScope.addToLocals(newMethod);
                }
            }
        }
    }
    
    public void visit(Extend extendsType) {
        Struct baseClass = extendsType.getType().struct;
        
        if (extendsType.getType() instanceof TypeCustom) {
        	TypeCustom type = (TypeCustom)extendsType.getType();
        	superclassName = type.getTypeName();
        }
        
        if (baseClass.getKind() != Struct.Class) {
            report_error("Moze se izvoditi samo iz klasa", extendsType);
        } else {
            currentClass.setElementType(extendsType.getType().struct);
            

            for (Obj field : extendsType.getType().struct.getMembers()) {
                if (field.getKind() == Obj.Fld) {
                    Obj newField = new Obj(field.getKind(), field.getName(), field.getType(), field.getAdr(),
                            field.getLevel());
                   
                    MyTab.currentScope.addToLocals(newField);
                }
            }
             
        }
    }
    
    public void visit(ClassDecl classDecl) {
    	
    	baseMethods.forEach((k, v) -> {
            if (v == false) {
                report_error("Klasa " + classDecl.getClassBegin().getClassName() + " nije implementirala metodu " + k
                        + " nasledjenu od apstraktne nadklase", classDecl);
                MyTab.currentScope.getLocals().deleteKey(k);
            }
        });
    	
        baseMethods.clear();
        
        currentClass = null;
        superclassName = "";
        MyTab.closeScope();
    }
    
    
// ABSTRACT CLASS
    
    public void visit(AbstractClassBegin classBegin) {
    	
        if (MyTab.currentScope.findSymbol(classBegin.getClassName())!=null) {
            report_error("Ime klase " + classBegin.getClassName() + " vec postoji u trenutnom opsegu", classBegin);
            currentClass = new Struct(Struct.None);
        } else {
            currentClass = new Struct(Struct.Class);
            MyTab.insert(Obj.Type, classBegin.getClassName(), currentClass);
            classBegin.struct = currentClass;
            abstractClasses.put(classBegin.getClassName(), false);
            report_info("Detektovana apstraktna unutrasnja klasa " + classBegin.getClassName() + " na liniji " + 
            		classBegin.getLine() + printNode(MyTab.find(classBegin.getClassName()), -1), classBegin);
        }
        inAbstractClass = true;
        abstractClassName = classBegin.getClassName();
        MyTab.openScope();
        MyTab.insert(Obj.Fld, "vtp", MyTab.intType);
    }
    
    public void visit(AbstractClassDecl classDecl) {
        baseMethods.clear();
        currentClass = null;
        inAbstractClass = false;
        MyTab.closeScope();
    }

    public void visit(AbstractMethodBegin abstractMethodBegin) {
        if (MyTab.currentScope.findSymbol(abstractMethodBegin.getMethodName()) != null && currentClass != null) {
            report_error("Ime " + abstractMethodBegin.getMethodName() + " vec postoji u opsegu apstraktne klase",
            		abstractMethodBegin);
        } else {
        	if (!inAbstractClass) {
        		report_error("Apstraktna metoda " + abstractMethodBegin.getMethodName() + " se ne moze deklarisati u klasi koja nije apstraktna",
                		abstractMethodBegin);
        		return;
        	}
        	abstractClassMethods.put(abstractMethodBegin.getMethodName(), abstractClassName);
        	abstractMethodBegin.obj = MyTab.insert(Obj.Meth, abstractMethodBegin.getMethodName(),
        			abstractMethodBegin.getReturnType().struct);
        }
        numberOfParameters = 0;
        MyTab.openScope();
        
        if (currentClass != null) {
        	Obj t = MyTab.insert(Obj.Var, "this", currentClass);
            t.setFpPos(1);
            numberOfParameters++;
        }
    }
    
    public void visit(AbstractMethodDecl abstractMethodDecl) {
        Obj method = abstractMethodDecl.getAbstractMethodBegin().obj;

        if (method != null) {
            MyTab.chainLocalSymbols(method);
            method.setLevel(numberOfParameters);
        }
        numberOfParameters = 0;
        MyTab.closeScope();
    }
    
// METHOD DECL
    
    public void visit(MethodBegin methodBegin) {
        Obj baseMethod = MyTab.currentScope.findSymbol(methodBegin.getMethodName());
        if (baseMethod != null && currentClass != null) {
            if (redefinedMethods.get(methodBegin.getMethodName()) != null) {
                if (redefinedMethods.get(methodBegin.getMethodName())) {
                    report_error("Nasledjena metoda " + methodBegin.getMethodName() + " je vec implementirana",
                            methodBegin);
                } else
                	redefinedMethods.replace(methodBegin.getMethodName(), true);
                	baseMethods.replace(methodBegin.getMethodName(), true);
                	abstractClassMethods.remove(methodBegin.getMethodName());
            }
            
            if (!baseMethod.getType().equals(methodBegin.getReturnType().struct)) {
                report_error("Prilikom redefinisanja metode " + methodBegin.getMethodName()
                        + " povratni tip se sme da se menja", methodBegin);
            } else {
                baseMethodVars = new ArrayList<>(baseMethod.getLocalSymbols());
                baseNumberOfParameters = baseMethod.getLevel();
                currentMethod = baseMethod;
                currentMethod.setLocals(null);
                methodBegin.obj = currentMethod;
            }
        } else if (baseMethod != null) {
            report_error("Ime " + methodBegin.getMethodName() + " vec postoji u trenutnom opsegu", methodBegin);
            currentMethod = new Obj(Obj.Meth, methodBegin.getMethodName(), MyTab.noType);
        } else {
            report_info("Zapoceta metoda " + methodBegin.getMethodName(), methodBegin);
            currentMethod = MyTab.insert(Obj.Meth, methodBegin.getMethodName(), methodBegin.getReturnType().struct);
            methodBegin.obj = currentMethod;
        }
        
        numberOfParameters = 0;
        isReturned = false;

        MyTab.openScope();

        if (currentClass != null) {
        	report_info("Metoda " + methodBegin.getMethodName(), methodBegin);
            Obj t = MyTab.insert(Obj.Var, "this", currentClass);
            t.setFpPos(1);
            numberOfParameters++;
        }
    }
    
    public void visit(MethodDecl methodDecl) {
        if (currentMethod != null) {
            if (!isReturned && currentMethod.getType() != MyTab.noType) {
                report_error("Metoda " + methodDecl.getMethodBegin().getMethodName() + " nema return naredbu", null);
            }
            if (currentMethod.getName().equals("main")) {
                if (numberOfParameters != 0) {
                    report_error("Metoda main ne sme imati argumente", null);
                } else if (currentMethod.getType() != MyTab.noType) {
                    report_error("Metoda main mora biti tipa void", null);
                } else {
                    foundMain = true;
                }
            }
        }

        redefinedMethods.replace(methodDecl.getMethodBegin().getMethodName(), false, true);

        isReturned = false;
        numberOfParameters = 0;
        baseNumberOfParameters = 0;
        currentMethod = null;
        baseMethodVars = null;
  
        MyTab.closeScope();
    }
    
    public void visit(FormParameter formPar) {
    	if(formPar.getBrackets() instanceof Bracket) {
			if(arrayTypes.get(formPar.getType().struct) == null)
				arrayTypes.put(formPar.getType().struct, new Struct(Struct.Array, formPar.getType().struct));
			formPar.getType().struct = arrayTypes.get(formPar.getType().struct);
		}

        if (MyTab.currentScope.findSymbol(formPar.getFormalParameterName()) != null) {
            report_error("Ime " + formPar.getFormalParameterName() + " vec postoji u trenutnom opsegu", formPar);
        } else {
            if (baseMethodVars != null) {
                if (baseNumberOfParameters <= numberOfParameters) {
                    report_error("Broj parametara u redefinisanoj metodi " + currentMethod.getName()
                            + " je veci nego u originalnoj", formPar);
                    return;
                } else if (!MyTab.Equals(baseMethodVars.get(numberOfParameters).getType(), formPar.getType().struct)) {
                    report_error(numberOfParameters + ". parametar ne odgovara po tipu parametru metode iz osnovne klase", formPar);
                    return;
                }
            }

            Obj newFormalParameter = MyTab.insert(Obj.Var, formPar.getFormalParameterName(), formPar.getType().struct);
            numberOfParameters++;
            newFormalParameter.setFpPos(numberOfParameters);
        }
    }
    
    public void visit(MethodFormParsEnd methodFormParsEnd) {
        if (currentMethod != null && baseMethodVars != null) {
            if (baseNumberOfParameters != numberOfParameters) {
                report_error("Broj parametara u redefinisanoj metodi je manji nego u originalnoj", methodFormParsEnd);
            }
        }
    }
    
    public void visit(MethodVarsEnd methodVarsEnd) {
        if (currentMethod != null) {
            MyTab.chainLocalSymbols(currentMethod);
            currentMethod.setLevel(numberOfParameters);
        }
    }

    public void visit(ReturnT returnT) {
        returnT.struct = returnT.getType().struct;
    }

    public void visit(ReturnVoid returnVoid) {
        returnVoid.struct = Tab.noType;
    }
	
// CONSTANT
	
	private ArrayList<Konstanta> constList = new ArrayList<>();
	
	public void visit(NumConst numConst) {
        numConst.konstanta = new Konstanta(MyTab.find("int"), numConst.getValue(), numConst.getLine());
    }

    public void visit(BoolConst boolConst) {
        boolConst.konstanta = new Konstanta(MyTab.find("bool"), boolConst.getValue() == true ? 1 : 0, boolConst.getLine());
    }

    public void visit(CharConst charConst) {
        charConst.konstanta = new Konstanta(MyTab.find("char"), charConst.getValue(), charConst.getLine());
    }

    public void visit(ConstantAssign constantAssign) {
    	constList.add(new Konstanta(constantAssign.getConst().konstanta.getObj(),
                constantAssign.getConst().konstanta.getValue(), constantAssign.getConstName(),
                constantAssign.getLine()));
    }
    
    public void visit(ConstantDecl constDecl) {
        for (Konstanta constant : constList) {
        	if (MyTab.currentScope().findSymbol(constant.getName()) != null) {
    			report_error("Konstanta " + constant.getName() + " vec deklarisana! ", null);
    		} else if (!MyTab.Equals(constant.getObj().getType(), constDecl.getType().struct)) {
    			report_error("Ne poklapa se tip vrednosti sa tipom konstante " + constDecl.getType() + "!", null);
    		} else {
    			 report_info("Deklarisana konstanta " + constant.getName() + "=" + constant.getValue(), constDecl);
    			 Obj ret = MyTab.insert(Obj.Con, constant.getName(), constant.getObj().getType());
                 ret.setAdr(constant.getValue());
    		}
        	
        }
        constList.clear();
    }
    
// GLOBAL VARIABLE
    
    private ArrayList<Variable> varList = new ArrayList<>();
    
    public void visit(MultipleVar multipleVar) {
        if (multipleVar.getVarSingle().variable != null) {
            varList.add(new Variable(multipleVar.getVarSingle().variable));
        }
    }

    public void visit(SingleVar singleVar) {
        if (singleVar.getVarSingle().variable != null) {
            varList.add(new Variable(singleVar.getVarSingle().variable));
        }
    }

    public void visit(VariableSingle variableSingle) {
        variableSingle.variable = new Variable(variableSingle.getVarName(),
                variableSingle.getBrackets() instanceof Bracket, variableSingle.getLine());
    }
    
    public void visit(VarDeclaration varDecl) {
        for (Variable variable : varList) {
            variable.setStruct(varDecl.getType().struct);
            
            if (MyTab.currentScope().findSymbol(variable.getName()) != null) {
    			report_error("Greska na liniji " + variable.getLine() + " : promenljiva " + variable.getName() + " vec deklarisana! ", null);
    		} {
    			if (variable.isArray()) {
    				if (arrayTypes.get(variable.getStruct()) == null) {
                        arrayTypes.put(variable.getStruct(), new Struct(Struct.Array, variable.getStruct()));
                    }
                    variable.setStruct(arrayTypes.get(variable.getStruct()));
    			}
    			
    			if (currentClass != null && currentMethod == null) {
                    report_info("Deklarisano polje klase " + variable.getName(), varDecl);
                    MyTab.insert(Obj.Fld, variable.getName(), variable.getStruct());
                } else {
                    if (currentMethod == null) {
                        report_info("Deklarisana globalna promenljiva " + variable.getName(), varDecl);
                    }
                    MyTab.insert(Obj.Var, variable.getName(), variable.getStruct());
                }
    		}
        }
        varList.clear();
    }
   
// STANDARD METHODS
    
   public void visit(StandardMethodChr standardFunctionChr) {
        Struct struct = standardFunctionChr.getExpr().struct;

        if (struct.getKind() != Struct.Int) {
            report_error("Argument mora biti tipa int", standardFunctionChr);
            return;
        }
        standardFunctionChr.struct = MyTab.find("chr").getType();
    }

    public void visit(StandardMethodOrd standardFunctionOrd) {
        Struct struct = standardFunctionOrd.getExpr().struct;

        if (struct.getKind() != Struct.Char) {
            report_error("Argument mora biti tipa char", standardFunctionOrd);
            return;
        } 
        standardFunctionOrd.struct = MyTab.find("ord").getType();
    }

    public void visit(StandardMethodLen standardFunctionLen) {
        Struct struct = standardFunctionLen.getExpr().struct;

        if (struct.getKind() != Struct.Array) {
            report_error("Argument mora biti niz", standardFunctionLen);
            return;
        }
        standardFunctionLen.struct = MyTab.find("len").getType();
    }
	
// TYPE
    
    public void visit(TypeInt typeInt) {
        typeInt.struct = MyTab.intType;
    }

    public void visit(TypeBool typeBool) {
        typeBool.struct = MyTab.boolType;
    }

    public void visit(TypeChar typeChar) {
        typeChar.struct = MyTab.charType;
    }
    
    public void visit(TypeCustom typeCustom) {
        Obj typeNode = MyTab.find(typeCustom.getTypeName());

        if (typeNode == MyTab.noObj) {
            report_error("Nije pronadjen tip " + typeCustom.getTypeName() + " u tabeli simbola", typeCustom);
            typeCustom.struct = MyTab.noType;
        } else {
            if (typeNode.getKind() == Obj.Type) {
                typeCustom.struct = typeNode.getType();
            } else {
                report_error("Ime " + typeCustom.getTypeName() + " ne predstavlja tip", typeCustom);
                typeCustom.struct = MyTab.noType;
            }
        }
    }

// STATEMENT
    
    public void visit(ForBegin forBegin) {
    	report_info("Detektovana upotreba for petlje" + " na liniji " + forBegin.getLine() 
    	+ ": " + printNode(MyTab.find(forBegin.getClass().getName()), -1), forBegin);
        loop++;
    }
    
    public void visit(StatementFor statementFor) {
        loop--;
    }

    public void visit(BreakStatement breakStatement) {
        if (loop <= 0) {
            report_error("Break moze da se koristi samo unutar petlje", breakStatement);
        }
    }

    public void visit(ContinueStatement continueStatement) {
        if (loop <= 0) {
            report_error("Continue moze da se koristi samo unutar petlje", continueStatement);
        }
    }

    public void visit(ReturnStatementNoExpr returnStatementNoExpr) {
        if (currentMethod == null) {
            report_error("Return ne sme da postoji van funkcije ili metode", returnStatementNoExpr);
        } else {
            isReturned = true;
            if (currentMethod.getType().getKind() != Struct.None) {
                report_error("Void metoda " + currentMethod.getName() + " ne sme imati return", returnStatementNoExpr);
            }
        }
    }

    public void visit(ReturnStatementWithExpr returnStatementWithExpr) {
        if (currentMethod == null) {
            report_error("Return ne sme da postoji van funkcije ili metode", returnStatementWithExpr);
        } else {
            isReturned = true;
            if (!MyTab.AssignableTo(currentMethod.getType(), returnStatementWithExpr.getExpr().struct)) {
                report_error("Povratni tip metode " + currentMethod.getName()
                        + " nije kompatibilan sa tipom povratne vrednosti", returnStatementWithExpr);
            }
        }
    }

    public void visit(ReadStatement readStatement) {
        if (isLValue(readStatement.getDesignator())) {
            Struct struct = readStatement.getDesignator().obj.getType();
            if (struct.getKind() != Struct.Int && struct.getKind() != Struct.Char && struct.getKind() != Struct.Bool) {
                report_error("Argument mora biti tipa int, char ili bool", readStatement);
            } else {
                report_info("Poziv funkcije read", readStatement);
            }
        } else {
            report_error("Argument funkcije read mora biti promenljiva, polje klase ili element niza", readStatement);
        }
    }

    public void visit(PrintStatement printStatement) {
        Struct struct = printStatement.getExpr().struct;
        
        if (struct.getKind() != Struct.Int && struct.getKind() != Struct.Char && struct.getKind() != Struct.Bool) {
            report_error("Argument funkcije print mora biti tipa int, char ili bool", printStatement);
        } else {
            report_info("Poziv funkcije print", printStatement);
        }
    }
    
//====================================================================================================================================
    
    private String printNode(Obj objToVisit, int kind) {
		StringBuilder output = new StringBuilder();
		switch (objToVisit.getKind()) {
		case Obj.Con:
			output.append("Con ");
			break;
		case Obj.Var:
			output.append("Var ");
			break;
		case Obj.Type:
			output.append("Type ");
			break;
		case Obj.Meth:
			output.append("Meth ");
			break;
		case Obj.Fld:
			output.append("Fld ");
			break;
		case Obj.Prog:
			output.append("Prog ");
			break;
		}

		output.append(objToVisit.getName());
		output.append(": ");

		if ((Obj.Var == objToVisit.getKind()) && "this".equalsIgnoreCase(objToVisit.getName())
				|| objToVisit.getKind() == kind)
			output.append("");
		else {
			Struct structToVisit = objToVisit.getType();
			switch (structToVisit.getKind()) {
			case Struct.None:
				output.append("NoType ");
				break;
			case Struct.Int:
				output.append("Int ");
				break;
			case Struct.Char:
				output.append("Char ");
				break;
			case Struct.Bool:
				output.append("Bool ");
				break;
			case Struct.Class:
				output.append("Class ");
				if (objToVisit.getKind() == Obj.Type) {
					output.append("[");
					for (Obj obj : structToVisit.getMembers()) {
						printNode(obj, structToVisit.getKind());
					}
					output.append("]");
				}
				break;
			case Struct.Array:
				output.append("Arr of ");

				switch (structToVisit.getElemType().getKind()) {
				case Struct.None:
					output.append("notype");
					break;
				case Struct.Int:
					output.append("int");
					break;
				case Struct.Char:
					output.append("char");
					break;
				case Struct.Bool:
					output.append("bool");
					break;
				case Struct.Class:
					output.append("Class");
					break;
				}
				break;
			}

			output.append(", ");
			output.append(objToVisit.getAdr());
			output.append(", ");
			output.append(objToVisit.getLevel() + " ");

		}
		return output.toString();
	}
    
    public boolean isLValue(Designator designator) {
        if (designator.obj == MyTab.noObj) {
            return false;
        }
        
        if (designator.obj.getKind() == Obj.Fld) {
            return true;
        }
        
        if (designator.obj.getKind() == Obj.Elem) {
            return true;
        }
        
        if (designator.obj.getKind() == Obj.Var && designator.obj.getType().getKind() != Struct.None) {
            return true;
        }
        return false;
    }
    
    public boolean passed() {
        return !errorDetected && foundMain;
    }
}
