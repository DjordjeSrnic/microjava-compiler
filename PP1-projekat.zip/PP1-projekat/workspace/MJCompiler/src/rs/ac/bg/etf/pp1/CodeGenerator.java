package rs.ac.bg.etf.pp1;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Stack;

import rs.ac.bg.etf.pp1.ast.*;
import rs.ac.bg.etf.pp1.help.*;
import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.concepts.*;

public class CodeGenerator extends VisitorAdaptor {

	private int mainPc;
	private Struct currentClass;
	private Obj currentMethod;
	private VirtualMethodTable virtualTable = new VirtualMethodTable();
	private HashMap<String, Integer> vtAdressMap = new HashMap<>(); 
	private Stack<ArrayList<Integer>> fixupTrueAddressStack = new Stack<>();
    private Stack<ArrayList<Integer>> fixupFalseAddressStack = new Stack<>();
    private Stack<Integer> condCheckReturnAddressStack = new Stack<>();
    private Stack<Integer> updateReturnAddressStack = new Stack<>();
    private Stack<ArrayList<Integer>> fixupBreakStack = new Stack<>();
    private Stack<ArrayList<Integer>> fixupContinueStack = new Stack<>();

	
	public int getMainPc() {
		return mainPc;
	}
	
// CLASS
	
	public void visit(ClassBegin classBegin) {
        currentClass = classBegin.struct;
		
        if (currentClass.getElemType() != null) {
            for (Obj parentMethod : currentClass.getElemType().getMembers()) {
                if (parentMethod.getKind() == Obj.Meth) {
                    Obj currentMethod = currentClass.getMembersTable().searchKey(parentMethod.getName());
                    currentMethod.setAdr(parentMethod.getAdr());
                }
            }
        }
        vtAdressMap.put(classBegin.getClassName(), Code.dataSize);
    }

    public void visit(ClassDecl classDecl) {
        for (Obj method : classDecl.getClassBegin().struct.getMembers()) {
            if (method.getKind() == Obj.Meth) {
                virtualTable.addFunctionEntry(method.getName(), method.getAdr());
            }
        }
        virtualTable.addTableTerminator();
        currentClass = null;
    }
    
    
    
// FUNC CALL
    
    public void visit(StandardMethodLen standardMethodLen) {
        Code.put(Code.arraylength);
    }

    public void visit(FunctionCall designatorFunctionCall) {
        callFunction(designatorFunctionCall.getDesignator());
    }

    public void visit(FuncCall factorFunctionCall) {
        callFunction(factorFunctionCall.getDesignator());
    }

    public void visit(CallBegin callBegin) {
        Designator designator = null;
        
        if (callBegin.getParent() instanceof FunctionCall) {
            designator = ((FunctionCall) callBegin.getParent()).getDesignator();
        }
        
        if (callBegin.getParent() instanceof FuncCall) {
            designator = ((FuncCall) callBegin.getParent()).getDesignator();
        }

        if (!(designator instanceof DotIdent) && currentClass != null 
    		&& currentMethod != null && !currentMethod.getLocalSymbols().contains(designator.obj) 
            && currentClass.getMembers().contains(designator.obj))
        {
            Code.put(Code.load);
            Code.put(0);
        }
    }

    private void callFunction(Designator designator) {
        if (designator instanceof DotIdent) {
            designator.traverseBottomUp(this);
            
            Code.put(Code.getfield);
            Code.put2(0);
            Code.put(Code.invokevirtual);
            
            String name = designator.obj.getName();
            for (int i = 0; i < name.length(); i++) {
                Code.put4(name.charAt(i));
            }
            Code.put4(-1);
        } else if (currentClass != null && currentClass.getMembers().contains(designator.obj)) {

            Code.put(Code.load);
            Code.put(0);

            Code.put(Code.getfield);
            Code.put2(0);
            Code.put(Code.invokevirtual);

            String name = designator.obj.getName();
            for (int i = 0; i < name.length(); i++) {
                Code.put4(name.charAt(i));
            }
            Code.put4(-1);
        } else {
            int dest_adr = designator.obj.getAdr() - Code.pc;
            Code.put(Code.call);
            Code.put2(dest_adr);
        }
    }
    
// METHOD
	
	public void visit(MethodBegin methodBegin) {
        Obj method = methodBegin.obj;
        if (methodBegin.getMethodName().equals("main")) {
            Code.mainPc = Code.pc;
        }
        
        method.setAdr(Code.pc);
        Code.put(Code.enter);
        Code.put(method.getLevel());
        Code.put(method.getLocalSymbols().size());
        currentMethod = method;

        if (methodBegin.getMethodName().equals("main")) {
            virtualTable.copyTable();
        }
    }
	
	public void visit(MethodDecl methodDecl) {
		Obj obj = methodDecl.getMethodBegin().obj;
		if (obj.getType() == MyTab.noType) {
			Code.put(Code.exit);
		    Code.put(Code.return_);
		} else {
			Code.put(Code.trap);
            Code.put(1);
		}
	    
        currentMethod = null;
    }
	
    public void visit(ReturnStatementNoExpr returnStatementNoExpr) {
    	Code.put(Code.exit);
        Code.put(Code.return_);
    }

    public void visit(ReturnStatementWithExpr returnStatementWithExpr) {
    	Code.put(Code.exit);
        Code.put(Code.return_);
    }
	
// CONST
    
	public void visit(NumConst numConst) {
		Code.loadConst(numConst.getValue());
    }

    public void visit(BoolConst boolConst) {
    	Code.loadConst(boolConst.getValue() == true ? 1 : 0);
    }

    public void visit(CharConst charConst) {
    	Code.loadConst(charConst.getValue());
    }
    
// READ AND PRINT
    
 	public void visit(ReadStatement readStatement) {
 		if(readStatement.getDesignator().obj.getType().getKind() == Struct.Char)
			Code.put(Code.bread);
		else
			Code.put(Code.read);
		Code.store(readStatement.getDesignator().obj);
     }
	
 	public void visit(PrintStatement printStatement) {
 		Struct t = printStatement.getExpr().struct;
 		
 		if (t == MyTab.intType || t == MyTab.boolType) {
			Code.put(Code.print);
		} else if (t == MyTab.charType) {
			Code.put(Code.bprint);
		} 
    }
 	
 	public void visit(PrintWithNumConst printWithNumConst) {
        Code.loadConst(printWithNumConst.getValue());
    }

    public void visit(PrintNoNumConst printNoNumConst) {
        Code.put(Code.const_5);
    }
 	
// OPERANDS

 	public void visit(DesignatorEnd designatorEnd) {
        Designator designator = null;
        
        if (designatorEnd.getParent() instanceof Var) {
            designator = ((Var) designatorEnd.getParent()).getDesignator();
        }
        
        if (designatorEnd.getParent() instanceof DotIdent) {
            DotIdent designatorPointAccess = (DotIdent) designatorEnd.getParent();
            designator = designatorPointAccess.getDesignator();
        }
        
        if (designatorEnd.getParent() instanceof BracketExpr) {
            designator = ((BracketExpr) designatorEnd.getParent()).getDesignator();
        }

        if (!(designator instanceof DotIdent) && currentClass != null && currentMethod != null
                && !currentMethod.getLocalSymbols().contains(designator.obj)
                && currentClass.getMembers().contains(designator.obj)) {
            Code.put(Code.load);
            Code.put(0);
        }
        Code.load(designator.obj);
    }
 	
	public void visit(AssignOper assignOper) {
        Code.store(assignOper.getDesignator().obj);      
    }
	
	
	public void visit(Assignop assignop) {
        Designator designator = ((AssignOper) assignop.getParent()).getDesignator();

        if (!(designator instanceof DotIdent) && currentClass != null && currentMethod != null
                && !currentMethod.getLocalSymbols().contains(designator.obj)
                && currentClass.getMembers().contains(designator.obj)) {
            Code.put(Code.load);
            Code.put(0);
        }
    }
	
	
// INSTANTIATION
	
    public void visit(ClassInstantiation classInst) {
        Code.put(Code.new_);
        Code.put2(classInst.struct.getNumberOfFields() * 4);
        Code.put(Code.dup);
        Code.loadConst(vtAdressMap.get(((TypeCustom) classInst.getType()).getTypeName())); 
        Code.put(Code.putfield);
        Code.put2(0);
    }
    
    public void visit(ArrayInstantiation arrayInst) {
        Code.put(Code.newarray);
        if (arrayInst.getType().struct == MyTab.charType) {
            Code.put(0);
        } else {
            Code.put(1);
        }
    }

// ARITHMETIC OPERATIONS    

    public void visit(AddOperation addOper) {
        Addop operation = addOper.getAddop();
        if (operation instanceof Plus) {
            Code.put(Code.add);
        } else if (operation instanceof Minus) {
            Code.put(Code.sub);
        }
    }

	public void visit(MulOperation mulOper) {
        Mulop operation = mulOper.getMulop();
        if (operation instanceof Multiply) {
            Code.put(Code.mul);
        } else if (operation instanceof Divide) {
            Code.put(Code.div);
        } else if (operation instanceof Modulo) {
            Code.put(Code.rem);
        }
    }
	
	public void visit(NegTerm negTerm) {
    	Code.put(Code.neg);
    }
	
	public void visit(Increment increment) {
        if (increment.getDesignator() instanceof BracketExpr)
            increment.getDesignator().traverseBottomUp(this);

        Code.load(increment.getDesignator().obj);
        Code.put(Code.const_1);
        Code.put(Code.add);
        Code.store(increment.getDesignator().obj);
    }
	
	public void visit(Decrement decrement) {
        if (decrement.getDesignator() instanceof BracketExpr)
            decrement.getDesignator().traverseBottomUp(this);

        Code.load(decrement.getDesignator().obj);
        Code.put(Code.const_1);
        Code.put(Code.sub);

        Code.store(decrement.getDesignator().obj);
    }
	
// CONDITION	

    public void visit(OrBegin orBegin) {
    	Code.putJump(0);
        fixupTrueAddressStack.peek().add(Code.pc - 2);
        fixupFalseAddressStack.peek().forEach(addr -> Code.fixup(addr));
        fixupFalseAddressStack.peek().clear();
    }

    public void visit(SingleExpr singleExpr) {
        Code.put(Code.const_1);
        Code.putFalseJump(Code.eq, 0);
        fixupFalseAddressStack.peek().add(Code.pc - 2);
    }
	
	public void visit(CompareExpr compareExpr) {
        if (compareExpr.getRelop() instanceof Equal) {
            Code.putFalseJump(Code.eq, 0);
        } else if (compareExpr.getRelop() instanceof NotEqual) {
            Code.putFalseJump(Code.ne, 0);
        } else if (compareExpr.getRelop() instanceof GreaterThan) {
            Code.putFalseJump(Code.gt, 0);
        } else if (compareExpr.getRelop() instanceof GreaterOrEqual) {
            Code.putFalseJump(Code.ge, 0);
        } else if (compareExpr.getRelop() instanceof LessThan) {
            Code.putFalseJump(Code.lt, 0);
        } else if (compareExpr.getRelop() instanceof LessOrEqual) {
            Code.putFalseJump(Code.le, 0);
        }
        fixupFalseAddressStack.peek().add(Code.pc - 2);
    }

// IF
	
	public void visit(StatementIfElse statementIfElse) {
		ArrayList<Integer> fix = fixupTrueAddressStack.pop();
        fix.forEach(adr -> Code.fixup(adr));
        fixupFalseAddressStack.pop();
    }

    public void visit(ElseBegin elseBegin) {
        Code.putJump(0);
        fixupTrueAddressStack.peek().add(Code.pc - 2);
        ArrayList<Integer> fix = fixupFalseAddressStack.peek();
        fix.forEach(adr -> Code.fixup(adr));
    }

    public void visit(StatementIf statementIf) {
        ArrayList<Integer> fix = fixupFalseAddressStack.pop();
        fix.forEach(adr -> Code.fixup(adr));
        fixupTrueAddressStack.pop();
    }

    public void visit(IfCondition ifCondition) {
        ArrayList<Integer> fix = fixupTrueAddressStack.peek();
        fix.forEach(adr -> Code.fixup(adr));
        fix.clear();
    }

    public void visit(IfBegin ifBegin) {
        fixupFalseAddressStack.push(new ArrayList<>());
        fixupTrueAddressStack.push(new ArrayList<>());
    }
	
// FOR
	
    public void visit(ForBegin forBegin) {
        fixupFalseAddressStack.push(new ArrayList<>());
        fixupTrueAddressStack.push(new ArrayList<>());
        fixupBreakStack.push(new ArrayList<>());
        fixupContinueStack.push(new ArrayList<>());
    }

    public void visit(OptDesignatorStatement optDesignatorStatement) {
        condCheckReturnAddressStack.push(Code.pc);
    }

    public void visit(NoOptDesignatorStatement noOptDesignatorStatement) {
    	condCheckReturnAddressStack.push(Code.pc);
    }

    public void visit(OptCondition optCondition) {
        Code.putJump(0);
        fixupTrueAddressStack.peek().add(Code.pc - 2);
        updateReturnAddressStack.push(Code.pc);
    }

    public void visit(NoOptCondition noOptCondition) {
        Code.putJump(0);
        fixupTrueAddressStack.peek().add(Code.pc - 2);
        updateReturnAddressStack.push(Code.pc);
    }

    public void visit(OptUpdateStatement optUpdateStatement) {
        Code.putJump(condCheckReturnAddressStack.peek());
        ArrayList<Integer> fix = fixupTrueAddressStack.peek();
        fix.forEach(adr -> Code.fixup(adr));
        fix.clear();
    }

    public void visit(NoOptUpdateStatement noOptUpdateStatement) {
        Code.putJump(condCheckReturnAddressStack.peek());
        ArrayList<Integer> fix = fixupTrueAddressStack.peek();
        fix.forEach(adr -> Code.fixup(adr));
        fix.clear();
    }

    public void visit(ForBody forBody) {
        fixupContinueStack.peek().forEach(adr -> Code.fixup(adr));
        Code.putJump(updateReturnAddressStack.peek());

        ArrayList<Integer> fix = fixupFalseAddressStack.pop();
        fix.forEach(adr -> Code.fixup(adr));
        fixupTrueAddressStack.pop();

        fixupBreakStack.peek().forEach(adr -> Code.fixup(adr));
    }

    public void visit(ForStatement forStatement) {
    	condCheckReturnAddressStack.pop();
    	updateReturnAddressStack.pop();
        fixupContinueStack.pop();
        fixupBreakStack.pop();
    }
	
	public void visit(BreakStatement breakStatement) {
        Code.putJump(0);
        fixupBreakStack.peek().add(Code.pc - 2);
    }

    public void visit(ContinueStatement continueStatement) {
        Code.putJump(0);
        fixupContinueStack.peek().add(Code.pc - 2);
    }
}



	
	