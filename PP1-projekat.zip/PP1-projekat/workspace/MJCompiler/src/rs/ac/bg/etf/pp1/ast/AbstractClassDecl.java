// generated with ast extension for cup
// version 0.8
// 1/1/2020 23:9:41


package rs.ac.bg.etf.pp1.ast;

public class AbstractClassDecl implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private AbstractClassBegin AbstractClassBegin;
    private Extends Extends;
    private ClassVarDeclList ClassVarDeclList;
    private AbstractClassMethodDeclList AbstractClassMethodDeclList;

    public AbstractClassDecl (AbstractClassBegin AbstractClassBegin, Extends Extends, ClassVarDeclList ClassVarDeclList, AbstractClassMethodDeclList AbstractClassMethodDeclList) {
        this.AbstractClassBegin=AbstractClassBegin;
        if(AbstractClassBegin!=null) AbstractClassBegin.setParent(this);
        this.Extends=Extends;
        if(Extends!=null) Extends.setParent(this);
        this.ClassVarDeclList=ClassVarDeclList;
        if(ClassVarDeclList!=null) ClassVarDeclList.setParent(this);
        this.AbstractClassMethodDeclList=AbstractClassMethodDeclList;
        if(AbstractClassMethodDeclList!=null) AbstractClassMethodDeclList.setParent(this);
    }

    public AbstractClassBegin getAbstractClassBegin() {
        return AbstractClassBegin;
    }

    public void setAbstractClassBegin(AbstractClassBegin AbstractClassBegin) {
        this.AbstractClassBegin=AbstractClassBegin;
    }

    public Extends getExtends() {
        return Extends;
    }

    public void setExtends(Extends Extends) {
        this.Extends=Extends;
    }

    public ClassVarDeclList getClassVarDeclList() {
        return ClassVarDeclList;
    }

    public void setClassVarDeclList(ClassVarDeclList ClassVarDeclList) {
        this.ClassVarDeclList=ClassVarDeclList;
    }

    public AbstractClassMethodDeclList getAbstractClassMethodDeclList() {
        return AbstractClassMethodDeclList;
    }

    public void setAbstractClassMethodDeclList(AbstractClassMethodDeclList AbstractClassMethodDeclList) {
        this.AbstractClassMethodDeclList=AbstractClassMethodDeclList;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(AbstractClassBegin!=null) AbstractClassBegin.accept(visitor);
        if(Extends!=null) Extends.accept(visitor);
        if(ClassVarDeclList!=null) ClassVarDeclList.accept(visitor);
        if(AbstractClassMethodDeclList!=null) AbstractClassMethodDeclList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(AbstractClassBegin!=null) AbstractClassBegin.traverseTopDown(visitor);
        if(Extends!=null) Extends.traverseTopDown(visitor);
        if(ClassVarDeclList!=null) ClassVarDeclList.traverseTopDown(visitor);
        if(AbstractClassMethodDeclList!=null) AbstractClassMethodDeclList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(AbstractClassBegin!=null) AbstractClassBegin.traverseBottomUp(visitor);
        if(Extends!=null) Extends.traverseBottomUp(visitor);
        if(ClassVarDeclList!=null) ClassVarDeclList.traverseBottomUp(visitor);
        if(AbstractClassMethodDeclList!=null) AbstractClassMethodDeclList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("AbstractClassDecl(\n");

        if(AbstractClassBegin!=null)
            buffer.append(AbstractClassBegin.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Extends!=null)
            buffer.append(Extends.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ClassVarDeclList!=null)
            buffer.append(ClassVarDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(AbstractClassMethodDeclList!=null)
            buffer.append(AbstractClassMethodDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [AbstractClassDecl]");
        return buffer.toString();
    }
}
