package rs.ac.bg.etf.pp1.help;

import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Struct;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Scope;

public class MyTab extends Tab {

	public static final Struct boolType = new Struct(Struct.Bool);
	
	public static void init() {
        
        Tab.init();

        Scope universe = currentScope = new Scope(null);

        universe.addToLocals(new Obj(Obj.Type, "int", intType));
        universe.addToLocals(new Obj(Obj.Type, "char", charType));
        universe.addToLocals(new Obj(Obj.Type, "bool", boolType));
        universe.addToLocals(new Obj(Obj.Con, "eol", charType, 10, 0));
        universe.addToLocals(new Obj(Obj.Con, "null", nullType, 0, 0));

        universe.addToLocals(chrObj = new Obj(Obj.Meth, "chr", charType, 0, 1));
        {
            openScope();
            currentScope.addToLocals(new Obj(Obj.Var, "i", intType, 0, 1));
            chrObj.setLocals(currentScope.getLocals());
            closeScope();
        }

        universe.addToLocals(ordObj = new Obj(Obj.Meth, "ord", intType, 0, 1));
        {
            openScope();
            currentScope.addToLocals(new Obj(Obj.Var, "ch", charType, 0, 1));
            ordObj.setLocals(currentScope.getLocals());
            closeScope();
        }

        universe.addToLocals(lenObj = new Obj(Obj.Meth, "len", intType, 0, 1));
        {
            openScope();
            currentScope.addToLocals(new Obj(Obj.Var, "arr", new Struct(Struct.Array, noType), 0, 1));
            lenObj.setLocals(currentScope.getLocals());
            closeScope();
        }
    }
	
	public static boolean CompatibleWith(Struct s1, Struct s2) {
        return (Equals(s1, s2) ||
        	    s1 == Tab.nullType && isRefType(s2) ||
        	    s2 == Tab.nullType && isRefType(s1));
    }
	
	public static boolean AssignableTo(Struct dest, Struct src) {
        if (Equals(dest, src) ||
        	isRefType(dest) && src == Tab.nullType) 
        {
            return true;
        }
        
        if (src.getKind() == Struct.Class) {
            for(Struct s=src.getElemType(); s != null; s=s.getElemType()) {
            	if (s.equals(dest))
            		return true;
            }
        }
       
        return false;
    }
	
	public static boolean Equals(Struct s1, Struct s2) {
        if (s1.getKind() == Struct.Array && s2.getKind() == Struct.Array) {
            return Equals(s1.getElemType(), s2.getElemType());
        }
        
        return s1 == s2;
    }
	
	public static boolean isRefType(Struct s) {
        return s.getKind() == Struct.Array || s.getKind() == Struct.Class;
    }

}
